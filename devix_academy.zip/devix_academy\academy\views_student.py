from django.shortcuts import render, redirect
from django.contrib import messages
from accounts.decorators import student_required
from academy.forms import StudentProfileEditForm


@student_required
def dashboard(request):
    """
    Student Dashboard:
    - Name, student ID, course, course duration, start/end dates.
    - Assigned Trainer FULL Profile Card (photo, name, phone, email, bio, tech, experience, social links).
    - Attendance summary: total days, present days, absent days, attendance % with progress bar.
    - Prominent certificate eligibility alert (>= 75% Green, < 75% Red).
    - Day-wise attendance table.
    """
    if not hasattr(request.user, 'student_profile'):
        messages.error(request, "Student profile not found. Please contact Branch Head.")
        return redirect('accounts:logout')
    student = request.user.student_profile
    trainer = student.trainer

    stats = student.get_attendance_stats()
    attendance_records = student.attendances.order_by('-date')

    return render(request, 'student/dashboard.html', {
        'student': student,
        'trainer': trainer,
        'stats': stats,
        'attendance_records': attendance_records,
    })


@student_required
def edit_profile(request):
    """Student edits own profile (name, student_class, profile picture, social links)."""
    student = request.user.student_profile
    if request.method == 'POST':
        form = StudentProfileEditForm(request.POST, request.FILES, instance=student)
        if form.is_valid():
            student = form.save()
            student.user.first_name = student.name.split()[0]
            student.user.last_name = " ".join(student.name.split()[1:]) if len(student.name.split()) > 1 else ""
            student.user.save()
            messages.success(request, "Your profile has been updated successfully!")
            return redirect('student:dashboard')
    else:
        form = StudentProfileEditForm(instance=student)

    return render(request, 'student/profile.html', {
        'form': form,
        'student': student,
    })
