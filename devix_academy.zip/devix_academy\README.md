# DeviX Academy - Training Institute Management System

**DeviX Academy by Ram Sir** is a production-ready, full-stack web application built with **Python 3.11+**, **Django 5.x**, and **Django REST Framework**. It provides complete, role-segregated management for training institutes covering Branch Administration, Faculty Operations, Student Portals, Daily Roll Call Attendance, Leave Management, and an Automated Faculty Payroll Calculation Engine.

---

## 🏛️ System Architecture & Roles

The system uses a custom `User` model with strict role isolation (`accounts.models.User`):

| Role | Access Level | Description |
| :--- | :--- | :--- |
| **BRANCH_HEAD** | Institute Director / Superuser | **Strictly ONE** account allowed across the entire database. Full CRUD over trainers, students, courses, departments, leave approvals, monthly attendance reports, and payroll generation. |
| **TRAINER** | Faculty Instructor | Profile management, student enrollment (auto ID & credential generator), daily roll call attendance marking, one-click self check-in, and leave applications. |
| **STUDENT** | Learner / Candidate | Profile viewing/updating, full mentor profile card, day-wise attendance log, attendance progress bar, and dynamic **Certificate Eligibility Warning/Confirmation** (>= 75% required). |

> **Security Rule:** No public self-registration. All user accounts are provisioned exclusively through institutional channels. Cross-role view access strictly returns **403 Forbidden**.

---

## 🚀 Key Features

### 1. 🏢 Branch Head Module
- **Analytics Dashboard**: Metric cards (Students, Faculty, Courses, Present Today, Pending Leaves) with clickable shortcuts, plus **Chart.js** data visualizations (Course Enrollment & Department breakdown).
- **Faculty Management**: Add faculty with monthly salary, department, technology stack, bio, and social media links. Reset passwords and delete trainers with confirmation modals.
- **Student Management**: Comprehensive student directory with filters by department, course, or mentor. Edit student details with ability to reassign courses or trainers.
- **Academic Programs (Courses & Departments)**: Full CRUD over courses, durations, fees, and departments (Tech / Non-Tech).
- **Leave Review**: Review, approve, or reject faculty leave applications with administrative remarks. When approved, dates are automatically logged as authorized leaves.
- **Attendance Matrix**: Visual calendar table showing day-by-day attendance status for all trainers across the month.
- **Payroll & Salary Slip Generator**:
  - Configurable formula: `Per_Day = Monthly_Salary / Working_Days`
  - `Net_Salary = Per_Day * (Present_Days + Approved_Paid_Leaves) - Unpaid_Absence_Deductions`
  - Printable invoice-style salary slip with institute letterhead, breakdown table, and signature zones.

### 2. 👨‍🏫 Trainer / Faculty Module
- **Overview Dashboard**: Active students count, today's check-in status (with one-click check-in), and approved leave balance.
- **Student Enrollment**: Enroll candidates with photo upload, Tech/Non-Tech department selector, and dynamic course dropdown filtered in real time via AJAX.
- **Instant Credential Issuance**: Auto-generates standardized student ID (e.g. `DVX-2026-0001`) and temporary secure password. Provides one-click "Copy Credentials" and "Print Credential Slip" buttons.
- **Roll Call Attendance**: Mark assigned student attendance day-by-day with date picker, "Mark All Present", and individual toggles. Prevents duplicate submissions.
- **Leave Application**: Submit leave requests with reason and track review status.
- **Personal Attendance Calendar**: Review personal check-in timestamps and attendance calendar for the month.

### 3. 🎓 Student Module
- **Personal Dashboard**: Student ID, Course track, duration, start/end dates.
- **Assigned Mentor Card**: Full profile card of assigned faculty mentor (portrait, contact phone/email, technologies taught, bio, and social profiles).
- **Attendance & Certificate Eligibility Engine**:
  - Calculates present vs. absent days and exact percentage: `(Present / Total) * 100`.
  - **Dynamic Eligibility Alert**:
    - **&ge; 75% Attendance**: Prominent green alert: *"You are eligible for certificate."*
    - **&lt; 75% Attendance**: Prominent red alert: *"Your attendance is below 75%. You are not eligible for the certificate."*
  - Day-wise chronological attendance history table.
- **Profile Edit**: Update student name, class/batch, portrait photo, and social links.

### 4. 🌐 Public Portal
- **Hero Section**: Welcome to DeviX Academy by Ram Sir with institute statistics.
- **Privacy-Safe Student Showcase**: Responsive grid displaying active students with **ONLY profile photo, name, and enrolled course**. No phone numbers, emails, or roll numbers are exposed.
- Real-time search and course filtering with pagination.

### 5. 🔌 REST API Endpoints (Django REST Framework)
- `/api/courses/` (Supports `?department=<id>` query parameter for AJAX dropdowns)
- `/api/departments/`
- `/api/trainers/`
- `/api/students/`
- `/api/attendance/`
- `/api/leaves/`
- `/api/salary/`

---

## 🛠️ Tech Stack & Requirements

- **Backend**: Python 3.11+, Django 5.x, Django REST Framework
- **Database**: SQLite default (switchable to PostgreSQL/MySQL via `.env`)
- **Frontend**: HTML5, CSS3, JavaScript (Fetch API), Bootstrap 5, FontAwesome 6, Chart.js
- **Media**: Pillow for image upload validation and processing
- **Environment**: `python-dotenv` for 12-factor configuration

---

## 📦 Quickstart Setup Guide

### Step 1: Clone or Extract the Project
```bash
cd devix_academy
```

### Step 2: Create and Activate Virtual Environment
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Configure Environment Variables
Copy `.env.example` to `.env` (already preconfigured with secure defaults for local development):
```bash
cp .env.example .env
```

### Step 5: Apply Database Migrations
```bash
python manage.py migrate
```

### Step 6: Create the Single Branch Head & Seed Demo Data
Run the custom management command:
```bash
python manage.py create_branch_head
```
This command:
1. Enforces the single Branch Head rule and provisions the `branchhead` account.
2. Seeds Tech & Non-Tech departments.
3. Seeds 6 industry courses.
4. Seeds 2 faculty trainers.
5. Seeds 5 students (including both eligible &lt;75% and &ge;75% attendance profiles).
6. Generates 25-day student roll calls, trainer check-ins, leave requests, and sample payroll slips.

### Step 7: Run the Development Server
```bash
python manage.py runserver
```
Visit:
- **Public Home**: `http://127.0.0.1:8000/`
- **Login Portal**: `http://127.0.0.1:8000/login/`
- **REST APIs**: `http://127.0.0.1:8000/api/`

---

## 🔑 Demo Login Credentials

| Role | Username | Password | Features to Test |
| :--- | :--- | :--- | :--- |
| **Branch Head** | `branchhead` | `Admin@12345` | Full Dashboard, Chart.js, Trainer/Student CRUD, Leave Approvals, Salary Computation & Slips |
| **Trainer 1** | `trainer_rahul` | `Trainer@12345` | Java Full Stack Mentor, Enroll Student (AJAX course filter), Mark Student Attendance, Self Check-in |
| **Trainer 2** | `trainer_priya` | `Trainer@12345` | AI/ML Mentor, Student roll call, Apply for leave |
| **Student (Eligible)** | `student_amit` | `Student@12345` | ~90% Attendance &bull; **Green Alert: "You are eligible for certificate."** &bull; Full Trainer card |
| **Student (Ineligible)**| `student_rohan` | `Student@12345` | ~60% Attendance &bull; **Red Alert: "Your attendance is below 75%..."** |

---

## 🧪 Running Automated Tests
Run the comprehensive test suite verifying authentication, single Branch Head enforcement, 403 access control, certificate eligibility logic, salary formula, and DRF API endpoints:
```bash
python manage.py test
```

---

## 🔒 Security Best Practices Implemented
- **CSRF Protection**: Token validated on every POST request and form submission.
- **Access Control**: Role-enforced view decorators (`@branch_head_required`, `@trainer_required`, `@student_required`) and class mixins.
- **File Validation**: Image type (JPEG/PNG/WEBP) and file size (&le; 5MB) checked on client and server.
- **Data Privacy**: Public portal strictly masks emails, phone numbers, and IDs.
- **Zero Secrets in Code**: Environment configuration via `.env`.

---
&copy; 2026 DeviX Academy. Engineered by Google Antigravity.
