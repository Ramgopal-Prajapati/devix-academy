from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import date, timedelta, time
from decimal import Decimal
from academy.models import Department, Course, TrainerProfile, StudentProfile
from attendance.models import Attendance, TrainerAttendance, LeaveRequest
from payroll.models import SalaryRecord

User = get_user_model()


class Command(BaseCommand):
    help = 'Creates the single DeviX Academy Branch Head and optionally seeds demo data.'

    def add_arguments(self, parser):
        parser.add_argument('--username', type=str, default='branchhead', help='Branch Head username')
        parser.add_argument('--email', type=str, default='branchhead@devixacademy.com', help='Branch Head email')
        parser.add_argument('--password', type=str, default='Admin@12345', help='Branch Head password')
        parser.add_argument('--no-seed', action='store_true', help='Skip seeding demo departments, courses, trainers, and students.')

    def handle(self, *args, **options):
        username = options['username']
        email = options['email']
        password = options['password']
        no_seed = options['no_seed']

        self.stdout.write(self.style.NOTICE("Initializing DeviX Academy Branch Head setup..."))

        # Check if Branch Head already exists
        existing_bh = User.objects.filter(role=User.Role.BRANCH_HEAD).first()
        if existing_bh:
            self.stdout.write(self.style.WARNING(
                f"[INFO] A Branch Head already exists: '{existing_bh.username}' ({existing_bh.email})."
            ))
            self.stdout.write(self.style.WARNING(
                "Per system rules, only ONE Branch Head is permitted. Creation of a second one is blocked."
            ))
            branch_head = existing_bh
        else:
            # Check if username exists with another role
            if User.objects.filter(username=username).exists():
                self.stdout.write(self.style.ERROR(f"Error: User with username '{username}' already exists with a different role."))
                return

            branch_head = User(
                username=username,
                email=email,
                first_name='Ram',
                last_name='Sir (Head)',
                role=User.Role.BRANCH_HEAD,
                is_staff=True,
                is_superuser=True
            )
            branch_head.set_password(password)
            branch_head.save()

            self.stdout.write(self.style.SUCCESS(
                f"[SUCCESS] Branch Head account successfully created!\n"
                f"   Username: {username}\n"
                f"   Email:    {email}\n"
                f"   Password: {password}\n"
                f"   Role:     {branch_head.get_role_display()}"
            ))

        if no_seed:
            self.stdout.write("Skipping demo data seeding as requested.")
            return

        self.stdout.write(self.style.NOTICE("\nSeeding demo data (Departments, Courses, Trainers, Students, Attendance)..."))

        # 1. Departments
        tech_dept, _ = Department.objects.get_or_create(
            name="Tech",
            defaults={"description": "Software Engineering, Full Stack Development, Data Science & AI."}
        )
        non_tech_dept, _ = Department.objects.get_or_create(
            name="Non-Tech",
            defaults={"description": "Digital Marketing, Creative Design, Product Management."}
        )
        self.stdout.write(self.style.SUCCESS("  [OK] Departments created: Tech, Non-Tech"))

        # 2. Courses
        courses_data = [
            ("Python Full Stack Development", tech_dept, "Complete Python, Django, DRF, PostgreSQL, HTML/CSS, React & Deployment.", "6 Months", Decimal('35000.00')),
            ("Java Full Stack Development", tech_dept, "Core Java, Advanced Java, Spring Boot, Microservices, Angular, MySQL & AWS.", "6 Months", Decimal('35000.00')),
            ("Data Science & Machine Learning", tech_dept, "Python, NumPy, Pandas, Scikit-Learn, Deep Learning, NLP, Power BI & Tableau.", "8 Months", Decimal('45000.00')),
            ("MERN Stack Web Development", tech_dept, "MongoDB, Express.js, React.js, Node.js, Next.js & Cloud Architecture.", "5 Months", Decimal('30000.00')),
            ("Digital Marketing & Growth", non_tech_dept, "SEO, SEM, Social Media Marketing, Content Strategy, Google Ads & Analytics.", "3 Months", Decimal('18000.00')),
            ("UI/UX Design & Branding", non_tech_dept, "Figma, Adobe XD, Design Systems, Wireframing, Prototyping & User Research.", "4 Months", Decimal('22000.00')),
        ]

        created_courses = {}
        for name, dept, desc, dur, fees in courses_data:
            c, _ = Course.objects.get_or_create(
                name=name,
                defaults={"department": dept, "description": desc, "duration": dur, "fees": fees, "is_active": True}
            )
            created_courses[name] = c
        self.stdout.write(self.style.SUCCESS(f"  [OK] {len(courses_data)} Courses created."))

        # 3. Trainers (2 Trainers)
        trainers_spec = [
            {
                "username": "trainer_rahul",
                "email": "rahul.sharma@devixacademy.com",
                "first_name": "Rahul",
                "last_name": "Sharma",
                "password": "Trainer@12345",
                "trainer_id": "TRN-001",
                "phone": "9876543210",
                "department": tech_dept,
                "bio": "Senior Full Stack Architect with 8+ years experience guiding industry aspirants into top-tier MNCs.",
                "experience_years": Decimal("8.5"),
                "experience_details": "Former Lead Developer at Infosys and Cognizant. Specializes in Java Microservices, Spring Boot, React, and cloud-native applications.",
                "technologies": "Java Full Stack, Spring Boot, Microservices, React.js, Web Development, MySQL, Docker",
                "linkedin": "https://linkedin.com/in/rahul-sharma-devix",
                "github": "https://github.com/rahul-devix",
                "monthly_salary": Decimal("65000.00"),
            },
            {
                "username": "trainer_priya",
                "email": "priya.patel@devixacademy.com",
                "first_name": "Priya",
                "last_name": "Patel",
                "password": "Trainer@12345",
                "trainer_id": "TRN-002",
                "phone": "9876543211",
                "department": tech_dept,
                "bio": "AI/ML Practitioner & Data Science Specialist passionate about making math and statistics practical for real-world applications.",
                "experience_years": Decimal("6.0"),
                "experience_details": "Ex-Data Scientist at Tiger Analytics. Delivered multiple production ML models and trained 800+ data engineers.",
                "technologies": "Data Science, Machine Learning, Python Full Stack, Deep Learning, Data Analytics, Pandas, TensorFlow",
                "linkedin": "https://linkedin.com/in/priya-patel-data",
                "github": "https://github.com/priya-patel",
                "monthly_salary": Decimal("70000.00"),
            }
        ]

        created_trainers = []
        for t_spec in trainers_spec:
            user = User.objects.filter(username=t_spec["username"]).first()
            if not user:
                user = User(
                    username=t_spec["username"],
                    email=t_spec["email"],
                    first_name=t_spec["first_name"],
                    last_name=t_spec["last_name"],
                    role=User.Role.TRAINER,
                    phone=t_spec["phone"]
                )
                user.set_password(t_spec["password"])
                user.save()

            trainer_profile, _ = TrainerProfile.objects.get_or_create(
                user=user,
                defaults={
                    "trainer_id": t_spec["trainer_id"],
                    "phone": t_spec["phone"],
                    "email": t_spec["email"],
                    "department": t_spec["department"],
                    "bio": t_spec["bio"],
                    "experience_years": t_spec["experience_years"],
                    "experience_details": t_spec["experience_details"],
                    "technologies": t_spec["technologies"],
                    "linkedin": t_spec["linkedin"],
                    "github": t_spec["github"],
                    "monthly_salary": t_spec["monthly_salary"],
                }
            )
            created_trainers.append(trainer_profile)
        self.stdout.write(self.style.SUCCESS(f"  [OK] {len(created_trainers)} Trainers created."))

        # 4. Students (5 Students)
        students_spec = [
            {
                "username": "student_amit",
                "name": "Amit Kumar",
                "email": "amit.kumar@gmail.com",
                "phone": "9876543221",
                "password": "Student@12345",
                "student_id": "DVX-2026-0001",
                "department": tech_dept,
                "course": created_courses["Python Full Stack Development"],
                "trainer": created_trainers[1], # Priya Patel
                "student_class": "Morning Batch A-1",
                "course_duration": "6 Months",
                "target_attendance_rate": 0.90, # Eligible
            },
            {
                "username": "student_sneha",
                "name": "Sneha Verma",
                "email": "sneha.verma@gmail.com",
                "phone": "9876543222",
                "password": "Student@12345",
                "student_id": "DVX-2026-0002",
                "department": tech_dept,
                "course": created_courses["Java Full Stack Development"],
                "trainer": created_trainers[0], # Rahul Sharma
                "student_class": "Weekend Pro Batch",
                "course_duration": "6 Months",
                "target_attendance_rate": 0.95, # Eligible
            },
            {
                "username": "student_rohan",
                "name": "Rohan Singh",
                "email": "rohan.singh@gmail.com",
                "phone": "9876543223",
                "password": "Student@12345",
                "student_id": "DVX-2026-0003",
                "department": tech_dept,
                "course": created_courses["Data Science & Machine Learning"],
                "trainer": created_trainers[1], # Priya Patel
                "student_class": "Evening AI Cohort",
                "course_duration": "8 Months",
                "target_attendance_rate": 0.60, # Below 75% -> Ineligible
            },
            {
                "username": "student_ananya",
                "name": "Ananya Iyer",
                "email": "ananya.iyer@gmail.com",
                "phone": "9876543224",
                "password": "Student@12345",
                "student_id": "DVX-2026-0004",
                "department": tech_dept,
                "course": created_courses["MERN Stack Web Development"],
                "trainer": created_trainers[0], # Rahul Sharma
                "student_class": "Morning Batch A-2",
                "course_duration": "5 Months",
                "target_attendance_rate": 0.85, # Eligible
            },
            {
                "username": "student_vikram",
                "name": "Vikram Patel",
                "email": "vikram.patel@gmail.com",
                "phone": "9876543225",
                "password": "Student@12345",
                "student_id": "DVX-2026-0005",
                "department": non_tech_dept,
                "course": created_courses["UI/UX Design & Branding"],
                "trainer": created_trainers[0], # Rahul Sharma
                "student_class": "Creative Studio Batch",
                "course_duration": "4 Months",
                "target_attendance_rate": 0.68, # Below 75% -> Ineligible
            },
        ]

        created_students = []
        today = date.today()
        start_date = today - timedelta(days=35)

        for s_spec in students_spec:
            user = User.objects.filter(username=s_spec["username"]).first()
            if not user:
                user = User(
                    username=s_spec["username"],
                    email=s_spec["email"],
                    first_name=s_spec["name"].split()[0],
                    last_name=" ".join(s_spec["name"].split()[1:]),
                    role=User.Role.STUDENT,
                    phone=s_spec["phone"]
                )
                user.set_password(s_spec["password"])
                user.save()

            student_profile, _ = StudentProfile.objects.get_or_create(
                user=user,
                defaults={
                    "student_id": s_spec["student_id"],
                    "name": s_spec["name"],
                    "email": s_spec["email"],
                    "phone": s_spec["phone"],
                    "department": s_spec["department"],
                    "course": s_spec["course"],
                    "trainer": s_spec["trainer"],
                    "course_duration": s_spec["course_duration"],
                    "start_date": start_date,
                    "end_date": start_date + timedelta(days=180),
                    "student_class": s_spec["student_class"],
                    "is_active": True,
                }
            )
            created_students.append((student_profile, s_spec["target_attendance_rate"]))
        self.stdout.write(self.style.SUCCESS(f"  [OK] {len(created_students)} Students created."))
        
        # 5. Student Attendance Records for the last 25 weekdays
        total_days = 25
        dates = []
        cur_date = today - timedelta(days=32)
        while len(dates) < total_days:
            if cur_date.weekday() < 5:  # Monday to Friday
                dates.append(cur_date)
            cur_date += timedelta(days=1)

        attendance_count = 0
        for student, target_rate in created_students:
            present_threshold = int(total_days * target_rate)
            for idx, d in enumerate(dates):
                status = "Present" if idx < present_threshold else "Absent"
                _, created = Attendance.objects.get_or_create(
                    student=student,
                    date=d,
                    defaults={
                        "status": status,
                        "marked_by": student.trainer.user if student.trainer else branch_head
                    }
                )
                if created:
                    attendance_count += 1
        self.stdout.write(self.style.SUCCESS(f"  [OK] {attendance_count} Student attendance logs generated."))

        # 6. Trainer Attendance Records
        trainer_att_count = 0
        for trainer in created_trainers:
            for d in dates:
                status = "Present"
                check_in_time = time(9, 30)
                # Give Rahul 2 leave days
                if trainer.trainer_id == "TRN-001" and d in dates[5:7]:
                    status = "Leave"
                    check_in_time = None
                _, created = TrainerAttendance.objects.get_or_create(
                    trainer=trainer,
                    date=d,
                    defaults={
                        "status": status,
                        "check_in": check_in_time
                    }
                )
                if created:
                    trainer_att_count += 1
        self.stdout.write(self.style.SUCCESS(f"  [OK] {trainer_att_count} Trainer attendance logs generated."))

        # 7. Leave Requests
        # Approved leave for Rahul Sharma
        LeaveRequest.objects.get_or_create(
            trainer=created_trainers[0],
            from_date=dates[5],
            to_date=dates[6],
            defaults={
                "reason": "Family function and personal travel.",
                "status": "Approved",
                "reviewed_by": branch_head,
                "remark": "Approved. Please coordinate student lab timings beforehand."
            }
        )

        # Pending leave for Priya Patel
        LeaveRequest.objects.get_or_create(
            trainer=created_trainers[1],
            from_date=today + timedelta(days=3),
            to_date=today + timedelta(days=4),
            defaults={
                "reason": "Attending AI/ML National Academic Summit.",
                "status": "Pending",
                "remark": ""
            }
        )
        self.stdout.write(self.style.SUCCESS("  [OK] Sample Leave Requests generated."))

        # 8. Sample Salary Record for previous month for Rahul Sharma
        prev_month = today.month - 1 if today.month > 1 else 12
        prev_year = today.year if today.month > 1 else today.year - 1
        
        working_days = 22
        present_days = 20
        leave_days = 2
        paid_leave_days = 2
        absent_days = 0
        per_day = Decimal("65000.00") / Decimal(working_days)
        deduction = Decimal("0.00")
        net = per_day * Decimal(present_days + paid_leave_days)

        SalaryRecord.objects.get_or_create(
            trainer=created_trainers[0],
            month=prev_month,
            year=prev_year,
            defaults={
                "monthly_salary": Decimal("65000.00"),
                "working_days": working_days,
                "present_days": present_days,
                "leave_days": leave_days,
                "paid_leave_days": paid_leave_days,
                "absent_days": absent_days,
                "per_day_salary": round(per_day, 2),
                "deduction": deduction,
                "net_salary": round(net, 2),
                "generated_by": branch_head,
                "notes": "Salary processed smoothly with 2 approved paid leaves."
            }
        )
        self.stdout.write(self.style.SUCCESS("  [OK] Sample Salary Record created for TRN-001."))

        self.stdout.write(self.style.SUCCESS(
            "\n" + "="*60 + "\n"
            "   DeviX Academy setup & demo data initialization COMPLETE!\n"
            "="*60 + "\n"
            "Demo Credentials Summary:\n"
            "  1. Branch Head:  username: 'branchhead'    | password: 'Admin@12345'\n"
            "  2. Trainer 1:    username: 'trainer_rahul' | password: 'Trainer@12345'\n"
            "  3. Trainer 2:    username: 'trainer_priya' | password: 'Trainer@12345'\n"
            "  4. Student 1:    username: 'student_amit'  | password: 'Student@12345' (Eligible: ~90%)\n"
            "  5. Student 2:    username: 'student_sneha' | password: 'Student@12345' (Eligible: ~95%)\n"
            "  6. Student 3:    username: 'student_rohan' | password: 'Student@12345' (Ineligible: ~60%)\n"
            "  7. Student 4:    username: 'student_ananya'| password: 'Student@12345' (Eligible: ~85%)\n"
            "  8. Student 5:    username: 'student_vikram'| password: 'Student@12345' (Ineligible: ~68%)\n"
            "="*60
        ))
