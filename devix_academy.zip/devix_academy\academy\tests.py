from django.test import TestCase, Client
from django.urls import reverse
from decimal import Decimal
from datetime import date
from accounts.models import User
from academy.models import Department, Course, TrainerProfile, StudentProfile, generate_student_id
from attendance.models import Attendance


class AcademyFunctionalityTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.dept = Department.objects.create(name="Tech", description="Technology courses")
        self.course = Course.objects.create(
            name="Python Full Stack",
            department=self.dept,
            description="Django & React",
            duration="6 Months",
            fees=Decimal("35000.00")
        )

        self.bh_user = User.objects.create_user(
            username='admin_ram',
            email='ram@devix.com',
            password='Password123!',
            role=User.Role.BRANCH_HEAD
        )

        self.trainer_user = User.objects.create_user(
            username='trainer_mark',
            email='mark@devix.com',
            password='Password123!',
            role=User.Role.TRAINER
        )
        self.trainer = TrainerProfile.objects.create(
            user=self.trainer_user,
            trainer_id="TRN-901",
            phone="9898989801",
            email="mark@devix.com",
            department=self.dept,
            monthly_salary=Decimal("60000.00")
        )

        self.student_user = User.objects.create_user(
            username='student_clara',
            email='clara@gmail.com',
            password='Password123!',
            role=User.Role.STUDENT
        )
        self.student = StudentProfile.objects.create(
            user=self.student_user,
            student_id="DVX-2026-0901",
            name="Clara Oswald",
            email="clara@gmail.com",
            phone="9898989899",
            department=self.dept,
            course=self.course,
            trainer=self.trainer,
            start_date=date.today()
        )

    def test_public_home_security_no_sensitive_data(self):
        """Verify public home displays student name and course, but NO email or phone."""
        response = self.client.get(reverse('public_home'))
        self.assertEqual(response.status_code, 200)
        content = response.content.decode('utf-8')
        self.assertIn("Clara Oswald", content)
        self.assertIn("Python Full Stack", content)
        self.assertNotIn("clara@gmail.com", content)
        self.assertNotIn("9898989899", content)

    def test_student_id_generator(self):
        """Verify student ID follows DVX-{year}-{0001} sequence."""
        sid = generate_student_id()
        self.assertTrue(sid.startswith("DVX-"))
        parts = sid.split("-")
        self.assertEqual(len(parts), 3)

    def test_certificate_eligibility_logic(self):
        """Verify attendance >= 75% is eligible and < 75% is ineligible."""
        # Record 4 attendance days: 3 Present, 1 Absent (75%)
        Attendance.objects.create(student=self.student, date=date(2026, 1, 1), status='Present')
        Attendance.objects.create(student=self.student, date=date(2026, 1, 2), status='Present')
        Attendance.objects.create(student=self.student, date=date(2026, 1, 3), status='Present')
        Attendance.objects.create(student=self.student, date=date(2026, 1, 4), status='Absent')

        stats = self.student.get_attendance_stats()
        self.assertEqual(stats['percentage'], 75.0)
        self.assertTrue(stats['is_eligible'])

        # Add 2 more Absent days (3 / 6 = 50.0%) -> Ineligible
        Attendance.objects.create(student=self.student, date=date(2026, 1, 5), status='Absent')
        Attendance.objects.create(student=self.student, date=date(2026, 1, 6), status='Absent')

        stats = self.student.get_attendance_stats()
        self.assertEqual(stats['percentage'], 50.0)
        self.assertFalse(stats['is_eligible'])

    def test_courses_api_filtered_by_department(self):
        """Verify /api/courses/?department=<id> filters courses correctly."""
        dept2 = Department.objects.create(name="Non-Tech")
        Course.objects.create(
            name="Graphic Design",
            department=dept2,
            description="Photoshop & Illustrator",
            duration="3 Months"
        )

        res = self.client.get(f'/api/courses/?department={self.dept.id}')
        self.assertEqual(res.status_code, 200)
        data = res.json()
        results = data if isinstance(data, list) else data.get('results', [])
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['name'], "Python Full Stack")
