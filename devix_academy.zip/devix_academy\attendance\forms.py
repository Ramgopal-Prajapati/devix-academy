from django import forms
from django.core.exceptions import ValidationError
from .models import LeaveRequest
import datetime


class LeaveRequestForm(forms.ModelForm):
    class Meta:
        model = LeaveRequest
        fields = ['from_date', 'to_date', 'reason']
        widgets = {
            'from_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'to_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'reason': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Reason for leave application...'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        from_date = cleaned_data.get('from_date')
        to_date = cleaned_data.get('to_date')

        if from_date and to_date:
            if to_date < from_date:
                raise ValidationError("End date cannot be earlier than start date.")
        return cleaned_data


class LeaveReviewForm(forms.ModelForm):
    class Meta:
        model = LeaveRequest
        fields = ['status', 'remark']
        widgets = {
            'status': forms.Select(
                choices=[('Approved', 'Approve Leave'), ('Rejected', 'Reject Leave')],
                attrs={'class': 'form-select'}
            ),
            'remark': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Optional remarks or instructions...'}),
        }
