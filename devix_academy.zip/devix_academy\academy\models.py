from django.db import models
from django.conf import settings
from django.utils import timezone
import datetime


class Department(models.Model):
    name = models.CharField(max_length=100, unique=True, help_text="e.g. Tech, Non-Tech")
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class Course(models.Model):
    name = models.CharField(max_length=150)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='courses')
    description = models.TextField()
    duration = models.CharField(max_length=50, help_text="e.g. 6 Months, 90 Days")
    fees = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Course fees in INR")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.department.name})"


class TrainerProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='trainer_profile'
    )
    trainer_id = models.CharField(max_length=30, unique=True, help_text="e.g. TRN-001")
    phone = models.CharField(max_length=20, unique=True)
    email = models.EmailField(unique=True)
    department = models.ForeignKey(
        Department,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='trainers'
    )
    profile_picture = models.ImageField(upload_to='trainers/', null=True, blank=True)
    bio = models.TextField(blank=True)
    experience_years = models.DecimalField(max_digits=4, decimal_places=1, default=0.0)
    experience_details = models.TextField(blank=True)
    technologies = models.TextField(
        blank=True,
        help_text="Comma-separated technologies e.g. Java Full Stack, Data Science, Web Development"
    )
    linkedin = models.URLField(blank=True)
    github = models.URLField(blank=True)
    instagram = models.URLField(blank=True)
    youtube = models.URLField(blank=True)
    twitter = models.URLField(blank=True)
    website = models.URLField(blank=True)
    monthly_salary = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0.00,
        help_text="Monthly gross salary set by Branch Head."
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['trainer_id']

    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} ({self.trainer_id})"

    @property
    def full_name(self):
        return self.user.get_full_name() or self.user.username

    def get_technologies_list(self):
        if not self.technologies:
            return []
        return [t.strip() for t in self.technologies.split(',') if t.strip()]

    @property
    def profile_picture_url(self):
        if self.profile_picture and hasattr(self.profile_picture, 'url'):
            return self.profile_picture.url
        return '/static/images/default-trainer.svg'


def generate_student_id():
    """Generates sequential student ID like DVX-2026-0001."""
    current_year = timezone.now().year
    prefix = f"DVX-{current_year}-"
    last_student = StudentProfile.objects.filter(
        student_id__startswith=prefix
    ).order_by('-student_id').first()

    if last_student:
        try:
            last_num_str = last_student.student_id.split('-')[-1]
            last_num = int(last_num_str)
            next_num = last_num + 1
        except (ValueError, IndexError):
            next_num = StudentProfile.objects.filter(student_id__startswith=prefix).count() + 1
    else:
        next_num = 1
    return f"{prefix}{next_num:04d}"


class StudentProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='student_profile'
    )
    student_id = models.CharField(max_length=30, unique=True, default=generate_student_id)
    name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20, unique=True)
    profile_picture = models.ImageField(upload_to='students/', null=True, blank=True)
    department = models.ForeignKey(
        Department,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='students'
    )
    course = models.ForeignKey(
        Course,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='students'
    )
    trainer = models.ForeignKey(
        TrainerProfile,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='students'
    )
    course_duration = models.CharField(max_length=50, blank=True)
    start_date = models.DateField(default=datetime.date.today)
    end_date = models.DateField(null=True, blank=True)
    student_class = models.CharField(max_length=100, blank=True, help_text="e.g. Batch A, Morning")
    linkedin = models.URLField(blank=True)
    github = models.URLField(blank=True)
    instagram = models.URLField(blank=True)
    twitter = models.URLField(blank=True)
    website = models.URLField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['student_id']

    def __str__(self):
        return f"{self.name} ({self.student_id})"

    @property
    def profile_picture_url(self):
        if self.profile_picture and hasattr(self.profile_picture, 'url'):
            return self.profile_picture.url
        return '/static/images/default-student.svg'

    def get_attendance_stats(self):
        from attendance.models import Attendance
        records = Attendance.objects.filter(student=self)
        total = records.count()
        present = records.filter(status='Present').count()
        absent = records.filter(status='Absent').count()
        pct = round((present / total * 100), 1) if total > 0 else 0.0
        return {
            'total': total,
            'present': present,
            'absent': absent,
            'percentage': pct,
            'is_eligible': pct >= 75.0,
        }
