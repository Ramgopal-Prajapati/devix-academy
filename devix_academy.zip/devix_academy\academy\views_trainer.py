from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q
from django.utils import timezone
from datetime import date, timedelta, time
import calendar

from accounts.decorators import trainer_required
from accounts.models import User
from academy.models import Department, Course, TrainerProfile, StudentProfile, generate_student_id
from attendance.models import Attendance, TrainerAttendance, LeaveRequest
from academy.forms import (
    TrainerProfileEditForm, StudentCreationForm,
    generate_secure_password
)
from attendance.forms import LeaveRequestForm


@trainer_required
def dashboard(request):
    """Trainer Dashboard overview."""
    if not hasattr(request.user, 'trainer_profile'):
        messages.error(request, "Trainer profile not found. Please contact Branch Head.")
        return redirect('accounts:logout')
    trainer = request.user.trainer_profile
    today = date.today()

    # My students count
    my_students_count = trainer.students.filter(is_active=True).count()

    # Today's attendance status
    today_att = TrainerAttendance.objects.filter(trainer=trainer, date=today).first()

    # Leave balance summary (e.g. approved leaves this month)
    leaves_this_month = LeaveRequest.objects.filter(
        trainer=trainer,
        status='Approved',
        from_date__year=today.year,
        from_date__month=today.month
    )
    approved_leave_days = sum(l.total_days for l in leaves_this_month)
    pending_leaves_count = LeaveRequest.objects.filter(trainer=trainer, status='Pending').count()

    # Recent student attendance marked
    recent_student_att_count = Attendance.objects.filter(
        student__trainer=trainer,
        date=today
    ).count()

    return render(request, 'trainer/dashboard.html', {
        'trainer': trainer,
        'my_students_count': my_students_count,
        'today_att': today_att,
        'approved_leave_days': approved_leave_days,
        'pending_leaves_count': pending_leaves_count,
        'recent_student_att_count': recent_student_att_count,
        'today': today,
    })


@trainer_required
def my_profile(request):
    """Trainer viewing & editing own profile. Cannot edit ID or salary."""
    trainer = request.user.trainer_profile
    if request.method == 'POST':
        form = TrainerProfileEditForm(request.POST, request.FILES, instance=trainer)
        if form.is_valid():
            trainer = form.save()
            trainer.user.phone = trainer.phone
            trainer.user.save()
            messages.success(request, "Your profile has been updated successfully!")
            return redirect('trainer:my_profile')
    else:
        form = TrainerProfileEditForm(instance=trainer)
    return render(request, 'trainer/profile.html', {'form': form, 'trainer': trainer})


@trainer_required
def student_list(request):
    """Trainer views only their assigned students."""
    trainer = request.user.trainer_profile
    query = request.GET.get('q', '').strip()

    students = trainer.students.filter(is_active=True).select_related('course', 'department')
    if query:
        students = students.filter(
            Q(student_id__icontains=query) |
            Q(name__icontains=query) |
            Q(email__icontains=query) |
            Q(phone__icontains=query) |
            Q(course__name__icontains=query)
        )

    return render(request, 'trainer/student_list.html', {
        'trainer': trainer,
        'students': students,
        'query': query,
    })


@trainer_required
def student_add(request):
    """
    Trainer enrolls a new student:
    - Course filtered via AJAX by department
    - Auto-generates student ID (like DVX-2026-0001)
    - Auto-generates random password
    - Displays credential card with copy and print buttons
    """
    trainer = request.user.trainer_profile
    if request.method == 'POST':
        form = StudentCreationForm(request.POST, request.FILES)
        if form.is_valid():
            data = form.cleaned_data

            # Generate student ID and secure random password
            student_id = generate_student_id()
            raw_password = generate_secure_password()
            username = f"std_{student_id.lower().replace('-', '_')}"

            # Create User account
            name_parts = data['name'].strip().split()
            first_name = name_parts[0]
            last_name = " ".join(name_parts[1:]) if len(name_parts) > 1 else ""

            user = User(
                username=username,
                email=data['email'],
                first_name=first_name,
                last_name=last_name,
                role=User.Role.STUDENT,
                phone=data['phone'],
                must_change_password=True
            )
            user.set_password(raw_password)
            user.save()

            # Create StudentProfile
            student = StudentProfile(
                user=user,
                student_id=student_id,
                name=data['name'],
                email=data['email'],
                phone=data['phone'],
                department=data['department'],
                course=data['course'],
                trainer=trainer,  # Automatically assigned to logged-in trainer
                course_duration=data.get('course_duration') or (data['course'].duration if data['course'] else ''),
                start_date=data['start_date'],
                end_date=data.get('end_date'),
                student_class=data.get('student_class', ''),
                profile_picture=data.get('profile_picture'),
                linkedin=data.get('linkedin', ''),
                github=data.get('github', ''),
                is_active=True
            )
            student.save()

            # Render credential display screen
            return render(request, 'trainer/student_created.html', {
                'student': student,
                'username': username,
                'raw_password': raw_password,
                'trainer': trainer,
            })
    else:
        form = StudentCreationForm(initial={'start_date': date.today()})

    return render(request, 'trainer/student_form.html', {
        'form': form,
        'trainer': trainer,
    })


@trainer_required
def student_detail(request, pk):
    """View assigned student profile & attendance."""
    trainer = request.user.trainer_profile
    student = get_object_or_404(trainer.students.select_related('course', 'department'), pk=pk)
    stats = student.get_attendance_stats()
    attendance_records = student.attendances.order_by('-date')[:25]
    return render(request, 'trainer/student_detail.html', {
        'student': student,
        'stats': stats,
        'attendance_records': attendance_records,
    })


@trainer_required
def mark_student_attendance(request):
    """Mark day-wise attendance for assigned students."""
    trainer = request.user.trainer_profile
    selected_date_str = request.GET.get('date', date.today().isoformat())

    try:
        selected_date = date.fromisoformat(selected_date_str)
    except ValueError:
        selected_date = date.today()

    students = trainer.students.filter(is_active=True).order_by('name')

    if request.method == 'POST':
        # Process attendance submissions
        marked_count = 0
        for student in students:
            status_val = request.POST.get(f"attendance_{student.id}")
            if status_val in ['Present', 'Absent']:
                Attendance.objects.update_or_create(
                    student=student,
                    date=selected_date,
                    defaults={
                        'status': status_val,
                        'marked_by': request.user
                    }
                )
                marked_count += 1
        messages.success(request, f"Attendance for {marked_count} students saved for {selected_date.strftime('%d %b %Y')}.")
        return redirect(f"{request.path}?date={selected_date.isoformat()}")

    # Fetch existing attendances for this date
    existing_records = Attendance.objects.filter(
        student__trainer=trainer,
        date=selected_date
    )
    existing_map = {att.student_id: att.status for att in existing_records}

    student_rows = []
    for s in students:
        student_rows.append({
            'student': s,
            'status': existing_map.get(s.id, 'Present')  # Default to Present for quick marking
        })

    return render(request, 'trainer/attendance_mark.html', {
        'selected_date': selected_date,
        'student_rows': student_rows,
        'today': date.today(),
    })


@trainer_required
def mark_my_attendance(request):
    """One-click attendance for the trainer for today."""
    trainer = request.user.trainer_profile
    today = date.today()

    att, created = TrainerAttendance.objects.get_or_create(
        trainer=trainer,
        date=today,
        defaults={
            'status': 'Present',
            'check_in': timezone.localtime().time()
        }
    )

    if created:
        messages.success(request, f"You have checked in successfully for today ({att.check_in.strftime('%I:%M %p')})!")
    else:
        messages.info(request, f"You have already marked attendance for today (Checked in at {att.check_in.strftime('%I:%M %p') if att.check_in else 'N/A'}).")

    return redirect('trainer:dashboard')


@trainer_required
def apply_leave(request):
    """Trainer applies for leave and views status history."""
    trainer = request.user.trainer_profile
    if request.method == 'POST':
        form = LeaveRequestForm(request.POST)
        if form.is_valid():
            leave = form.save(commit=False)
            leave.trainer = trainer
            leave.status = 'Pending'
            leave.save()
            messages.success(request, f"Leave application for {leave.total_days} day(s) submitted successfully. Waiting for Branch Head review.")
            return redirect('trainer:apply_leave')
    else:
        form = LeaveRequestForm(initial={'from_date': date.today()})

    leave_history = trainer.leave_requests.order_by('-applied_on')
    return render(request, 'trainer/leave_apply.html', {
        'form': form,
        'leave_history': leave_history,
    })


@trainer_required
def my_attendance_summary(request):
    """Monthly attendance calendar & summary for the trainer."""
    trainer = request.user.trainer_profile
    today = date.today()
    selected_month = int(request.GET.get('month', today.month))
    selected_year = int(request.GET.get('year', today.year))

    num_days = calendar.monthrange(selected_year, selected_month)[1]
    days_list = [date(selected_year, selected_month, d) for d in range(1, num_days + 1)]

    records = TrainerAttendance.objects.filter(
        trainer=trainer,
        date__year=selected_year,
        date__month=selected_month
    )
    records_map = {r.date.day: r for r in records}

    days_data = []
    present_count = 0
    leave_count = 0
    absent_count = 0

    for d in days_list:
        rec = records_map.get(d.day)
        st = rec.status if rec else ('Absent' if d.weekday() < 5 and d <= today else '-')
        check_in = rec.check_in if rec else None

        days_data.append({
            'date': d,
            'day': d.day,
            'is_weekend': d.weekday() >= 5,
            'status': st,
            'check_in': check_in,
        })

        if st == 'Present':
            present_count += 1
        elif st == 'Leave':
            leave_count += 1
        elif st == 'Absent':
            absent_count += 1

    month_names = [(i, calendar.month_name[i]) for i in range(1, 13)]

    return render(request, 'trainer/attendance_summary.html', {
        'trainer': trainer,
        'days_data': days_data,
        'present_count': present_count,
        'leave_count': leave_count,
        'absent_count': absent_count,
        'selected_month': selected_month,
        'selected_year': selected_year,
        'month_name': calendar.month_name[selected_month],
        'month_names': month_names,
    })
