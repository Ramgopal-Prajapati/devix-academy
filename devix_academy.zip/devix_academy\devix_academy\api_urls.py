from django.urls import path, include
from rest_framework.routers import DefaultRouter
from academy.api import (
    CourseViewSet, DepartmentViewSet, TrainerViewSet,
    StudentViewSet, AttendanceViewSet, LeaveRequestViewSet,
    SalaryRecordViewSet
)

router = DefaultRouter()
router.register(r'courses', CourseViewSet, basename='api-course')
router.register(r'departments', DepartmentViewSet, basename='api-department')
router.register(r'trainers', TrainerViewSet, basename='api-trainer')
router.register(r'students', StudentViewSet, basename='api-student')
router.register(r'attendance', AttendanceViewSet, basename='api-attendance')
router.register(r'leaves', LeaveRequestViewSet, basename='api-leave')
router.register(r'salary', SalaryRecordViewSet, basename='api-salary')

urlpatterns = [
    path('', include(router.urls)),
]
