from django.urls import path
from . import views_trainer as views

app_name = 'trainer'

urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('profile/', views.my_profile, name='my_profile'),

    # Students
    path('students/', views.student_list, name='student_list'),
    path('students/add/', views.student_add, name='student_add'),
    path('students/<int:pk>/', views.student_detail, name='student_detail'),

    # Attendance
    path('attendance/students/', views.mark_student_attendance, name='mark_student_attendance'),
    path('attendance/mark-self/', views.mark_my_attendance, name='mark_my_attendance'),
    path('attendance/summary/', views.my_attendance_summary, name='my_attendance_summary'),

    # Leaves
    path('leaves/apply/', views.apply_leave, name='apply_leave'),
]
